<template>
  <v-app>
  </v-app>
</template>

<script>
export default {
  name: "Mobile"
}
</script>

<style scoped>

</style>
