<template>
  <router-view />
</template>
<style>
  #app, .v-application {
    background-color: grey;
  }
</style>
<script setup>
  //
</script>
